const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 8080;

// Configure CORS
app.use(cors());

// Configure app to use body-parser
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect('mongodb://mongodb:27017')
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch((error) => {
        console.error('Error connecting to MongoDB:', error);
    });

// MongoDB model
const Topic = require('./models/topics');

// Routes
const router = express.Router();

router.post('/topics', (req, res) => {
    console.log('[POST] Topics');
    
    const topic = new Topic(req.body);
    topic.save()
        .then(() => {
            res.json({ message: 'Topic created!' });
        })
        .catch((err) => {
            res.status(500).json({ error: err.message });
        });
});

router.get('/topics', (req, res) => {
    console.log('[GET] Topics');
    
    Topic.find()
        .then((topics) => {
            res.json(topics);
        })
        .catch((err) => {
            res.status(500).json({ error: err.message });
        });
});

// All routes will be prefixed with /api
app.use('/api', router);

// Start the server
app.listen(port, () => {
    console.log(`Server up and running on port ${port}`);
});

